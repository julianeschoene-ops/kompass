const STORAGE_KEY = 'kompass41_data';
const LEGACY_KEYS = ['kompass33_sprints','kompass33_subjects','kompass33_pupils','kompass33_competencies','kompass33_records','kompass33_lebDrafts','kompass33_metadata'];

function clone(obj){ return JSON.parse(JSON.stringify(obj)); }
function uid(prefix='id'){ return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7); }

const Store = {
  data: null,
  load(){
    const current = localStorage.getItem(STORAGE_KEY);
    if(current){
      try{
        this.data = JSON.parse(current);
        this.migrate();
        this.save();
        return;
      }catch(error){
        console.error('KOMPASS-Daten konnten nicht geladen werden:', error);
        localStorage.setItem(STORAGE_KEY + '_fehlerhafte_sicherung_' + Date.now(), current);
      }
    }
    const legacy = localStorage.getItem('kompass33_pupils');
    if(legacy){
      this.data = {
        version:'7.0',
        subjects: JSON.parse(localStorage.getItem('kompass33_subjects') || 'null') || clone(SEED.subjects),
        coreSubjects: clone(SEED.coreSubjects),
        sprints: JSON.parse(localStorage.getItem('kompass33_sprints') || 'null') || clone(SEED.sprints),
        pupils: JSON.parse(localStorage.getItem('kompass33_pupils') || 'null') || clone(SEED.pupils),
        competencies: JSON.parse(localStorage.getItem('kompass33_competencies') || 'null') || clone(SEED.competencies),
        records: JSON.parse(localStorage.getItem('kompass33_records') || '{}'),
        lebDrafts: JSON.parse(localStorage.getItem('kompass33_lebDrafts') || '{}'),
        settings: { scoreConfig:{...DEFAULT_SCORE_CONFIG} },
        activities:[], activityRecords:{}, behaviour:{}, coaching:{}, projectTemplates:clone(SEED.projectTemplates),creativeRooms:clone(SEED.creativeRooms),workshopPaths:{},clubMemberships:{},assignments:[],choiceImports:[],sprintHistory:{},clubHistory:{},dailyCreativeVisits:{},timetable:{teachers:[],rooms:[],groups:[],requirements:[],plans:[{id:'plan_a',name:'Plan A',lessons:[]}],activePlanId:'plan_a',importedAt:null},
        metadata: JSON.parse(localStorage.getItem('kompass33_metadata') || '{}')
      };
      this.migrate(); this.save(); return;
    }
    this.data = {version:'7.0',subjects:clone(SEED.subjects),coreSubjects:clone(SEED.coreSubjects),sprints:clone(SEED.sprints),pupils:clone(SEED.pupils),competencies:clone(SEED.competencies),records:{},lebDrafts:{},activities:[],activityRecords:{},behaviour:{},coaching:{},settings:{scoreConfig:{...DEFAULT_SCORE_CONFIG}},projectTemplates:clone(SEED.projectTemplates),creativeRooms:clone(SEED.creativeRooms),workshopPaths:{},clubMemberships:{},assignments:[],choiceImports:[],sprintHistory:{},clubHistory:{},dailyCreativeVisits:{},timetable:{teachers:[],rooms:[],groups:[],requirements:[],plans:[{id:'plan_a',name:'Plan A',lessons:[]}],activePlanId:'plan_a',importedAt:null},metadata:{createdAt:new Date().toISOString(),version:'7.0'}};
    this.save();
  },
  migrate(){
    const d=this.data;
    d.version='7.1';
    d.subjects=d.subjects||clone(SEED.subjects);
    d.coreSubjects=d.coreSubjects||clone(SEED.coreSubjects);
    d.sprints=d.sprints||clone(SEED.sprints);
    d.pupils=d.pupils||[];
    d.competencies=d.competencies||[];
    d.records=d.records||{};
    d.lebDrafts=d.lebDrafts||{};
    d.activities=d.activities||[];
    d.activityRecords=d.activityRecords||{};
    d.behaviour=d.behaviour||{};
    d.coaching=d.coaching||{};
    d.projectTemplates=d.projectTemplates||clone(SEED.projectTemplates);
    d.creativeRooms=d.creativeRooms||clone(SEED.creativeRooms);
    d.workshopPaths=d.workshopPaths||{};
    d.clubMemberships=d.clubMemberships||{};
    // Neue Datenbereiche aus KOMPASS 6.0 müssen auch bei bestehenden
    // Datensicherungen aus 4.x/5.x ergänzt werden. Sonst ist z. B.
    // Store.assignments undefined und bereits das Dashboard bricht ab.
    d.assignments=Array.isArray(d.assignments)?d.assignments:[];
    d.choiceImports=Array.isArray(d.choiceImports)?d.choiceImports:[];
    d.sprintHistory=d.sprintHistory||{};
    d.clubHistory=d.clubHistory||{};
    d.dailyCreativeVisits=d.dailyCreativeVisits||{};
    d.calendarEvents=Array.isArray(d.calendarEvents)?d.calendarEvents:[];
    d.auditLog=Array.isArray(d.auditLog)?d.auditLog:[];
    d.timetable=d.timetable||{teachers:[],rooms:[],groups:[],requirements:[],plans:[{id:'plan_a',name:'Plan A',lessons:[]}],activePlanId:'plan_a',importedAt:null};
    d.timetable.teachers=d.timetable.teachers||[];d.timetable.rooms=d.timetable.rooms||[];d.timetable.groups=d.timetable.groups||[];d.timetable.requirements=d.timetable.requirements||[];d.timetable.plans=d.timetable.plans?.length?d.timetable.plans:[{id:'plan_a',name:'Plan A',lessons:[]}];d.timetable.activePlanId=d.timetable.activePlanId||d.timetable.plans[0].id;
    d.timetable.generator=d.timetable.generator||{periods:9,corePeriods:[2,3,4],latePeriods:[5,6],maxTeacherDay:7,avoidFirstCore:true,lastRun:null,report:null};d.timetable.school=d.timetable.school||{};
    d.settings=d.settings||{};
    d.settings.scoreConfig=d.settings.scoreConfig||{...DEFAULT_SCORE_CONFIG};
    d.metadata=d.metadata||{};
    d.metadata.version='7.1';
    d.sprints.forEach(s=>{ if(!s.id)s.id='s'+s.year+'_'+s.number; if(s.startDate===undefined)s.startDate=''; if(s.endDate===undefined)s.endDate=''; });
    d.competencies.forEach((c,i)=>{
      if(!c.id)c.id=uid('comp');
      if(!c.type)c.type=c.subject==='Prozess'||c.kind==='prozess'?'process':(CORE_SUBJECTS.includes(c.subject)?'core':'workshop');
      if(!c.category)c.category=c.area||'Allgemein';
      if(!c.area)c.area=c.category;
      if(c.includeInLeb===undefined)c.includeInLeb=true;
      if(c.order===undefined)c.order=i*10;
      if(c.maxPoints===undefined)c.maxPoints=null;
      if(!c.scoreConfig)c.scoreConfig={...DEFAULT_SCORE_CONFIG};
      if(c.note===undefined)c.note='';
    });
    SEED.competencies.forEach(c=>{ if(!d.competencies.some(x=>x.id===c.id)) d.competencies.push(clone(c)); });
    d.subjects=WORKSHOP_SUBJECTS.slice();
    SEED.sprints.forEach(s=>{ if(!d.sprints.some(x=>x.year===s.year&&x.number===s.number)) d.sprints.push(clone(s)); });
  },
  _lastSnapshot:null,
  saveLocalOnly(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data)); this._lastSnapshot=JSON.stringify(this.data); },
  changedSections(before,after){ const keys=new Set([...Object.keys(before||{}),...Object.keys(after||{})]); return [...keys].filter(k=>k!=='auditLog'&&JSON.stringify(before?.[k])!==JSON.stringify(after?.[k])); },
  log(action='Änderung gespeichert',details={}){
    this.data.auditLog=this.data.auditLog||[];
    const u=(typeof Auth!=='undefined'&&Auth.currentUser)?Auth.currentUser():null;
    this.data.auditLog.push({id:uid('log'),at:new Date().toISOString(),userId:u?.id||null,user:u?.name||'System',role:u?.role||null,action,details,sections:details.sections||[]});
    if(this.data.auditLog.length>2500)this.data.auditLog=this.data.auditLog.slice(-2500);
    localStorage.setItem(STORAGE_KEY,JSON.stringify(this.data));
  },
  save(action='Änderung gespeichert',details={}){
    let before={}; try{before=this._lastSnapshot?JSON.parse(this._lastSnapshot):JSON.parse(localStorage.getItem(STORAGE_KEY)||'{}')}catch(e){}
    const sections=this.changedSections(before,this.data);
    if(sections.length){this.data.auditLog=this.data.auditLog||[];const u=(typeof Auth!=='undefined'&&Auth.currentUser)?Auth.currentUser():null;this.data.auditLog.push({id:uid('log'),at:new Date().toISOString(),userId:u?.id||null,user:u?.name||'System',role:u?.role||null,action,details:{...details,sections},sections});if(this.data.auditLog.length>2500)this.data.auditLog=this.data.auditLog.slice(-2500);}
    this.saveLocalOnly();
    if(typeof Sync!=='undefined'&&Sync.schedule)Sync.schedule();
  },
  exportData(){ return {...this.data, exportedAt:new Date().toISOString()}; },
  importData(data){ if(!data || !Array.isArray(data.pupils) || !Array.isArray(data.competencies)){ alert('Diese Datei sieht nicht wie eine KOMPASS-Datensicherung aus.'); return false; } this.data=data; this.migrate(); this.save(); return true; }
};
Store.load();
Store._lastSnapshot=JSON.stringify(Store.data);
Object.defineProperties(Store,{sprints:{get(){return this.data.sprints},set(v){this.data.sprints=v}},subjects:{get(){return this.data.subjects},set(v){this.data.subjects=v}},coreSubjects:{get(){return this.data.coreSubjects},set(v){this.data.coreSubjects=v}},pupils:{get(){return this.data.pupils},set(v){this.data.pupils=v}},competencies:{get(){return this.data.competencies},set(v){this.data.competencies=v}},records:{get(){return this.data.records},set(v){this.data.records=v}},lebDrafts:{get(){return this.data.lebDrafts},set(v){this.data.lebDrafts=v}},activities:{get(){return this.data.activities},set(v){this.data.activities=v}},activityRecords:{get(){return this.data.activityRecords},set(v){this.data.activityRecords=v}},behaviour:{get(){return this.data.behaviour},set(v){this.data.behaviour=v}},coaching:{get(){return this.data.coaching},set(v){this.data.coaching=v}},settings:{get(){return this.data.settings},set(v){this.data.settings=v}},metadata:{get(){return this.data.metadata},set(v){this.data.metadata=v}},projectTemplates:{get(){return this.data.projectTemplates},set(v){this.data.projectTemplates=v}},creativeRooms:{get(){return this.data.creativeRooms},set(v){this.data.creativeRooms=v}},workshopPaths:{get(){return this.data.workshopPaths},set(v){this.data.workshopPaths=v}},clubMemberships:{get(){return this.data.clubMemberships},set(v){this.data.clubMemberships=v}},assignments:{get(){return this.data.assignments},set(v){this.data.assignments=v}},choiceImports:{get(){return this.data.choiceImports},set(v){this.data.choiceImports=v}},sprintHistory:{get(){return this.data.sprintHistory},set(v){this.data.sprintHistory=v}},clubHistory:{get(){return this.data.clubHistory},set(v){this.data.clubHistory=v}},dailyCreativeVisits:{get(){return this.data.dailyCreativeVisits},set(v){this.data.dailyCreativeVisits=v}},calendarEvents:{get(){return this.data.calendarEvents},set(v){this.data.calendarEvents=v}},auditLog:{get(){return this.data.auditLog},set(v){this.data.auditLog=v}},timetable:{get(){return this.data.timetable},set(v){this.data.timetable=v}}});
